
import json
import boto3
from botocore.exceptions import ClientError
import datetime

def setReminder_handler(event, context):
    # Inputs
    userId = event["UserID"]
    id = event["id"]
    time_stamp = datetime.datetime.strptime(event["trigger_date"], "%d/%m/%Y").timestamp()
    reminder_ttl = int(time_stamp)
    reminder_type = event["type"]
    message = event["message"]

    #Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='eu-west-1')
    
    #Add item into table
    table = dynamodb.Table("reminders")
    resp_message = "The reminder has been added successfully"
    status_code = 200

    try:
        table.put_item(
            Item={
                "UserID": userId,
                "id": id,
                "ttl": reminder_ttl,
                "type": reminder_type,
                "message": message 
            }
        )
    except ClientError as err:
        resp_message = err.response['Error']['Message']
        status_code = 500

    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
        },
        "body": json.dumps({
            "message": resp_message
        })
    }
